#include "spritelib/spritelib.h"

#include <fstream>
#include <streambuf>
#include <vector>
#include <iostream>

using namespace spritelib;
using namespace std;

// Let's create some sprites!
Sprite animatedSprite;

// A vector container to hold all of the sprites we want to draw
std::vector<Sprite*> spritesToDraw;

// Back to front selection sort, to solve the depth issues with transparent sprites
void IterativeSelectionSort(std::vector<Sprite*>& a_sprites);
// Let's move him around the screen
void UpdateHaggar(Sprite &a_sprite);
// A scrolling background function
void HorizontalScroll(Sprite &a_sprite);

void KeyboardFunc(Window::Key a_key, Window::EventType a_eventType)
{
    switch (a_eventType)
    {
        case Window::EventType::KeyPressed:
        {
            if (a_key == Window::Key::Escape)
            {
                std::cout << "Escape was pressed!" << std::endl;
            }

            break;
        }
        case Window::EventType::KeyReleased:
        {
            break;
        }
    }
}

void MouseFunc(Window::Button a_button, int a_mouseX, int a_mouseY, Window::EventType a_eventType)
{ }

void Update()
{
	if(GetAsyncKeyState(VK_RIGHT))
    animatedSprite.next_frame();
}

void DrawSprites()
{
    IterativeSelectionSort(spritesToDraw);

    // Let's draw each sprite
    for (auto itr = spritesToDraw.begin(), itrEnd = spritesToDraw.end(); itr != itrEnd; itr++)
        ( *itr )->draw();
}

int main()
{
    // Let's make a game window. use the static function get_game_window to get a handle to the main game window
    Window& theGame = Window::get_game_window(); // This is a singleton, useful for managing one window https://en.wikipedia.org/wiki/Singleton_pattern
    theGame.init("MY GAME", 800, 600)
        .set_screen_size(800, 600)
        .set_keyboard_callback(KeyboardFunc)
        .set_mouse_callback(MouseFunc)
        .set_clear_color(255, 255, 255);

	animatedSprite.load_sprite_image("assets/images/pop_turn.png")
		.set_sprite_frame_size(43,103);
    spritesToDraw.push_back(&animatedSprite);

    // IMPORTANT: This is how spritelib 2.0 handles the main game loop
    while (theGame.update(30))
    {
        // You can put movement code inside of this update function, it is called every frame
		
        Update();

        // You can put sprite drawing code inside of this draw function
        DrawSprites();
    }

    return 0;
}

// Back to front selection sort, to solve the depth issues with transparent sprites
// https://en.wikipedia.org/wiki/Selection_sort
void IterativeSelectionSort(std::vector<Sprite*>& a_sprites)
{
    for (unsigned int i = 0; i < a_sprites.size(); i++)
    {
        int minIndex = i;
        for (unsigned int j = i; j < a_sprites.size(); j++)
        {
            if (a_sprites[j]->get_depth() < a_sprites[minIndex]->get_depth())
            {
                minIndex = j;
            }
        }
        std::swap(a_sprites[minIndex], a_sprites[i]);
    }
}